<!DOCTYPE html>
<html>
<head>
	<title>My page</title>
</head>
<body>
    
<h1>
    <strong style="color:blue;">
        <?php 
            $a = 'Hello World!';
            echo $a;
        ?>
    </strong>
</h1>

</body>
</html>

